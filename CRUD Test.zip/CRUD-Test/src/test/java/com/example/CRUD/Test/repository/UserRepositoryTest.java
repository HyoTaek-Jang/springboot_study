package com.example.CRUD.Test.repository;

import org.springframework.beans.factory.annotation.Autowired;

public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;


}